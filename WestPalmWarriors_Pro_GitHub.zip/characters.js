const fighters=[
{name:'95 Rich'},
{name:'Dragon Master'},
{name:'Moon Dancer'},
{name:'Titan X'}
];