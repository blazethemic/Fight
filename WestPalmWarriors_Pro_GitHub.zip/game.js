let selected=0;
let level=0;

function showCharacters(){
menu.classList.add('hidden');
characters.classList.remove('hidden');
}

function pick(id){
selected=id;
}

function startGame(){
characters.classList.add('hidden');
hud.classList.remove('hidden');
loadLevel();
}

function loadLevel(){
document.getElementById('level').innerHTML='LEVEL '+(level+1)+' - '+cities[level];
}